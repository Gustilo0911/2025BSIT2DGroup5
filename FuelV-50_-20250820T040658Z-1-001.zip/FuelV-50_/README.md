
# Fuel V - Scan & Go (Sign In update)
This package includes the updated Sign In page (separate page) matching the requested design.

Run: extract into XAMPP htdocs, start Apache, visit http://localhost/FuelV-Final-SignIn/
